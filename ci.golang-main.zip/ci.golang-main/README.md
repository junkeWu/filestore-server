# 满金坝 golang 项目仓库的模板



## 主要介绍

*本模板主要集成CI/CD自动化流水线*

---

###目录介绍

- [ ] .gitlab/cd_templates 用于k8s发布的yaml文件模板，可根据业务需求更改，正常无需改动
- [ ] .gitlab/Ci_templates 用于自动构建服务用到的模板
- [ ] docker/build 放置构建的运行文件、静态资源文件、日志目录等
- [ ] docker/Dockerfile 构建镜像文件，正常无需改动

---
###需要根据项目调整的文件

- [ ] .gitlab-ci.yml  项目CI/CD流水线配置文件，正常无需改动
- [ ] .gitlab-env.yml 项目CI/CD所需的环境变量，根据项目进行更改调整
- [ ] .golangci.yml  GO项目代码检查的配置文件，根据实际情况调整或删除
